alert{'Hello Flask!'};
//$('dojo').hover(function(){
//  $('h4').text('Click Me!');
//})
