alert('hello ninja!');
